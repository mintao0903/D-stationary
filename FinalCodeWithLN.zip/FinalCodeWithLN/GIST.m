function [x,output] = GIST(A,b,K,lambda,pm,x_input)
% % Algorithm 2 NPGmajorj
% % title: A general iterative shrinkage and thresholding algorithm 
% %        for non-convex regularized optimization problems. 
% % ref:   http://proceedings.mlr.press/v28/gong13a.pdf
if isfield(pm,'L')
    L = pm.L;
else
    L = norm(A'*A);
end
if isfield(pm,'gista_tau')
    tau = pm.gista_tau;
else
    tau = 1.5;
end
if isfield(pm,'gista_c')
    c = pm.gista_c;
else
    c = 1;
end
if isfield(pm,'gista_M')
    M = pm.gista_M;
else
    M = 1;
end

AA = A'*A; Ab = A'*b;
L_min = 1; L_max = L+1e3; 

x1 = x_input; x0 =  x_input;

maxit = 5000;
output.obj = [];
obj_val = zeros(maxit,1);
obj_val(1,1) = objnew(x1,A,b,lambda,K);

for k = 1:maxit
    dxk = x1 - x0; dyk = AA * (x1-x0); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    d1d2 = (dxk'*dyk) / (dxk'*dxk);    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Lt = min(L_max, max(L_min, d1d2)); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    d = AA*x1 - Ab;
    ind_min = max(k-M,0) + 1;
    max_F_val = max(obj_val(ind_min:1:k,1));
    while (Lt <= L_max)
        x2 = prox_norm1K(K,lambda/Lt,x1-d/Lt);
        Fu = objnew(x2,A,b,lambda,K);
        if Fu <= max_F_val - 0.5 * c * Lt * norm(x2-x1)^2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            break;
        end
        Lt = tau*Lt;
    end
    obj_val(k+1,1) = objnew(x2,A,b,lambda,K);
    output.obj = [output.obj, obj_val(k+1,1)];
    x0 = x1; x1 = x2;
    if abs(obj_val(k+1,1)-obj_val(k,1)) <= 1e-8 && k > 5
        break;
    end
end
x = x2;
end

%% 
function out = prox_norm1K(K,lambda,x)
% proximal mapping of lambda * (||x||_1 - |||x|||_K)
out = sign(x) .* max(abs(x)-lambda,0);
[~,ind] = sort(abs(x),'descend');
out(ind(1:1:K),1) = x(ind(1:1:K),1); 
end