function [x_output,output] = mAPG_ALG2(A,b,K,lambda,pm,x_input)
% %
% % Closed solution: proximal mapping of lambda * (||x||_1 - |||x|||_K)
% %
% % Algorithm 2 monotone APG with line search
% % title: Accelerated Proximal Gradient Methods for Nonconvex Programming
% % ref:   https://zhouchenlin.github.io/Publications/2015-NIPS-APG_supp.pdf
if isfield(pm,'delta')
    delta = pm.delta;
else
    delta = 0.1;
end
if isfield(pm,'rho')
    rho = pm.rho;
else
    rho = 0.5;
end

AA = A'*A; Ab = A'*b;

x0 = x_input; x1 = x_input; z1 = x_input; 
y0 = x_input + 1e-6; v1 = x_input + 1e-6;
t1 = 1; t0 = 1;

maxit = 5e3;
output.obj = [];
for k = 1:maxit
    % % 0 means k-1, 1 means k, 2 means k+1
    % update alphax and alphay
    s1 = z1 - y0; r1 = AA * (z1-y0);
    alphay = (s1'*s1)/(s1'*r1); % alphay = (s1'*r1)/(r1'*r1);
    s1 = v1 - x0; r1 = AA * (v1-x0);
    alphax = (s1'*s1)/(s1'*r1); % alphax = (s1'*r1)/(r1'*r1);
    
    % update y
    y1 = x1 + (t0/t1)*(z1-x1)+((t0-1)/t1)*(x1-x0);

    % update z
    Fy1 = objnew(y1,A,b,lambda,K);
    count = 0; % avoid endless loops
    while (count <= 1e3)
        ry = lambda*alphay;
        gy = y1-alphay*(AA*y1-Ab);
        z2 = prox_norm1K(K,ry,gy);
        Fz2 = objnew(z2,A,b,lambda,K);
        if Fz2 <= Fy1 - delta * norm(z2-y1)^2
            break;
        end
        alphay = rho * alphay;
        count = count + 1;
    end

    % update v
    Fx1 = objnew(x1,A,b,lambda,K);
    count = 0; % avoid endless loops
    while (count <= 1e3)
        rx = lambda*alphax;
        gx = x1-alphax*(AA*x1-Ab);
        v2 = prox_norm1K(K,rx,gx);
        Fv2 = objnew(v2,A,b,lambda,K);
        if Fv2 <= Fx1 - delta * norm(v2-x1)^2
            break;
        end
        alphax = rho * alphax;
        count = count + 1;
    end

    % update t, x
    t2 = (1+sqrt(1+4*t1*t1))/2;
    fgz = objnew(z2,A,b,lambda,K);
    fgv = objnew(v2,A,b,lambda,K);
    if fgz < fgv
        x2 = z2;
    else
        x2 = v2;
    end

    obj1 = objnew(x1,A,b,lambda,K);
    obj2 = objnew(x2,A,b,lambda,K);
    output.obj = [output.obj, obj2];
    if abs(obj2-obj1) < 1e-8 && k >= 5
        break;
    end

    x0 = x1; x1 = x2;
    t0 = t1; t1 = t2;
    y0 = y1; z1 = z2; v1 = v2;
end
x_output = x2;
end

%% 
function out = prox_norm1K(K,lambda,x)
% proximal mapping of lambda * (||x||_1 - |||x|||_K)
out = sign(x) .* max(abs(x)-lambda,0);
[~,ind] = sort(abs(x),'descend');
out(ind(1:1:K),1) = x(ind(1:1:K),1); 
end