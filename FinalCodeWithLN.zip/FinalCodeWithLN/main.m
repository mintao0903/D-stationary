clc; close all; 
rng(10)
K = 5;%%for each setting, run K times and get average
J = 1;  obj_record = zeros(K,7);
        time_record = zeros(K,7);
       
 for kk = 1:K
    for j = 10:10
        n = 500*j;K = 150*j;
        lambda = 5*j;
        v = randn(K,1);
        [~,index] = sort(abs(v),'descend');
        v = v(index);
        x_real = zeros(n,1);
        for i = 1:K
            x_real(i) = v(i)+sign(v(i));
        end
        x_real(K+1) = v(K)+sign(v(K));
        x_real(K+2) = x_real(K+1);
        d = unifrnd(-sqrt(lambda),sqrt(lambda),n,1);
        d = sort(d,'descend');
        A = diag(d) + 0.01*unifrnd(-1/n,1/n,n,n);
        w1 = lambda*sign(x_real);
        w2 = zeros(n,1);
        w2(1:K) = lambda*sign(x_real(1:K));
        b = A'\(A'*A*x_real+w1-w2);
        
        pm.L = norm(A'*A);
        pm.tau = 1;
        pm.c = pm.tau*pm.tau*pm.L;
        pm.eta = 0.1;
        x0 = x_real + 0.05*unifrnd(-1,1,n,1);
        t1 = cputime;
        [x,output] = PEDCAe(A, b, K, lambda, pm, x0);%PEDCAe
        t1 = cputime - t1;
        tmp = objnew(x, A, b, lambda, K);
        obj_record(kk,1)  = tmp;
        time_record(kk,1) = t1;
        fprintf('\nExperiment on K = %d, n = %d, lambda = %d', K,n,lambda);
        fprintf('\n PEDCAe:obj  value = %f, t=%4.2f\n',objnew(x,A,b,lambda,K),t1);
         t2 = cputime;
        [x2,output2] = PEDCA0(A, b, K, lambda, pm, x0);%PEDCA
        t2 = cputime - t2;
        tmp = objnew(x2, A, b, lambda, K);
        obj_record(kk,2)  = tmp;
        time_record(kk,2) = t2;
        
        fprintf('\n PEDCA:obj  value = %f, t=%4.2f\n',objnew(x2,A,b,lambda,K),t2);
        
        pm.tau = 1; 
        t3=cputime;
        [x3,output3] =SPDCAe(A,b,K,lambda,pm,x0);%sPDCAe
        t3=cputime-t3;
        obj_record(kk,3)  = objnew(x3,A,b,lambda,K);
        time_record(kk,3) = t3;
         fprintf('\n PDCAe   obj  value = %f, t=%4.2f\n',objnew(x3,A,b,lambda,K),t3);

        pm.npg_tau = 1.5; pm.npg_M = 5; pm.npg_c = 1;
        t4=cputime;
        [x4,output4] = NPG_major(A,b,K,lambda,pm,x0);
        t4=cputime-t4;
        obj_record(kk,4)  = objnew(x4,A,b,lambda,K);
        time_record(kk,4) = t4;
        fprintf('\n NPG  obj  value = %f, t=%4.2f\n',objnew(x4,A,b,lambda,K),t4);

        pm.gista_tau = 1.5; pm.gista_M = 5; pm.gista_c = 0.2;
        t5=cputime;
        [x5,output5] = GIST(A,b,K,lambda,pm,x0);t5=cputime-t5;%GIST
        obj_record(kk,5)  = objnew(x5,A,b,lambda,K);
        time_record(kk,5) = t5;
        fprintf('\n GIST    obj  value = %f, t=%4.2f\n',objnew(x5,A,b,lambda,K),t5);

        % Algorithm 1 monotone APG with fixed stepsize
        % Closed solution: proximal mapping of lambda * (||x||_1 - |||x|||_K)
        pm.alphax = 1/(pm.L+1e-6); pm.alphay = pm.alphax;
        t6=cputime;
        [x6,output6] = mAPG_ALG1(A,b,K,lambda,pm,x0);t6=cputime-t6;%APG_Alg1
        obj_record(kk,6)  = objnew(x6,A,b,lambda,K);
        time_record(kk,6) = t6;
        fprintf('\nmAPG_1  obj  value = %f, t=%4.2f\n',objnew(x6,A,b,lambda,K),t6);

      

        % Algorithm 2 monotone APG with line search
        % Linearization of |||x|||_{K}
        pm.delta = 0.1; pm.rho = 0.6;t7=cputime;
        [x7,output7] = mAPG_ALG2_linear(A,b,K,lambda,pm,x0);t7=cputime-t7; %APG_Alg2
        obj_record(kk,7)  = objnew(x7,A,b,lambda,K);
        time_record(kk,7) = t7;
        fprintf('\n mAPG_2L obj  value = %f, t=%4.2f\n', objnew(x7,A,b,lambda,K),t7);
        
        fprintf('\n------------------------------------------------------------------------------\n')
    end
   
    
     
 end
     m_obj = mean(obj_record);
     m_time = mean(time_record);
     fprintf('\n------------------------------------------------------------------------------\n')
     disp('   PEDCAe & PEDCA  &   sPDCAe  & NPG   &  GIST  &  mAPG1 &  mAPG2  \n');
     disp(m_obj);
     fprintf('\n------------------------------------------------------------------------------\n')
     disp(m_time);