function [x,output] = EPDCA1(A, b, K, lambda, pm, x_input)
%%%   based on Algorithm 2 in 'Enhanced proximal DC algorithms with extrapolation for a
%%%class of structured nonsmooth DC minimization'

%%%   x: the output solution
%%%   output.obj: record the value of objective function at each iteration
%%%   output.count: record the number of elements in A(x,eta) at each iteration
if isfield(pm,'L')
    L = pm.L;
else
    L = norm(A'*A);
end
if isfield(pm, 'tau')
    tau = pm.tau;
else
    tau = 0.5;
end
if isfield(pm, 'c')
    c = pm.c;
else
    c = tau*tau*L;
end
if isfield(pm, 'eta')
    eta = pm.eta;
else
    eta = 0.1;
end
xold = x_input;
x = xold;
theta0 = 1;
theta = 1;
N = length(xold);
output.obj = [];
output.count = [];
for k = 1:5000
    beta = tau*(theta0-1)/theta;
    z = x  + beta*(x-xold);
    v = g(x,K,lambda);%% value of g(x),i.e. lambda*sum of top k largest component of x in magnitude
    [x_sort,ind] = sort(abs(x),'descend');
    F_min = inf;
    %%%get rid of some elements in x that are impossible to appear in A(x,eta)
    sum1 = sum(x_sort(1:K-1));
    for kk = K+1:N
        if lambda*(sum1+x_sort(kk)) < v-eta
            break
        end
    end
    count = 0;
    %%% because x can be sorted, the question is to traverse all the combinations that choose K index in [1:kk]
    %%% the algorithm to traverse combinations without additional storage space follows the mothod 2 in the website below
    %%% https://leetcode-cn.com/problems/combinations/solution/zu-he-by-leetcode-solution/
    %%% and the file 'combination.m' shows a demo of this combination algorithm 
    j = 1;
    temp = [1:K, kk+1];
    while j <= K
           %%% judge whether the current index combination is in A(x,eta)   
           if lambda*sum(x_sort(temp(1:K))) >= v-eta
               %%% get the index before sorting
               I = ind(temp(1:K));
               G = grad(x, I, lambda, N);%%%gradient when the active index is I
               xnew = softthresholding((c*x + L*z - A'*(A*z-b) + G)/(L+c),lambda/(L+c));%%% solve sub problem by softthresholding
               F = obj(xnew, A, b, lambda, K) + 0.5*c*norm(xnew-x,2)^2;
               if F < F_min
                   F_min = F;
                   xmin = xnew;
               end
               count = count+1;
           end
        j = 1;
        while j<=K && temp(j)+1==temp(j+1)
            temp(j) = j;
            j = j+1;
        end
        temp(j) = temp(j)+1;
    end
                
    xold = x;
    x = xmin;
    theta0 = theta;
    theta = (1 + sqrt(1 + 4*theta*theta))/2;
    output.obj = [output.obj, obj(x,A,b,lambda,K)];
    output.count = [output.count, count];
    if abs(obj(x,A,b,lambda,K)-obj(xold,A,b,lambda,K))<=1e-8 && k>5
        break
    end
    if mod(k,200)==0 || (z-x)'*(x-xold)>0
        theta = 1;
        theta0 = 1;
    end
end
end

%%% lambda*sum of top k largest component of x in magnitude
function v = g(x,K,lambda)
y = sort(abs(x),'descend');
v = lambda*sum(y(1:K));
end
%%% gradient when the active index is I
function G = grad(x,I,lambda,N)
G = zeros(N,1);
for i = 1:length(I)
    if x(I(i))>0
        G(I(i)) = lambda;
    elseif x(I(i))<0
        G(I(i)) = -lambda;
    end
end
end
function F = obj(x,A,b,lambda,K)
F = 0.5*norm(A*x-b,2)^2+lambda*norm(x,1)-g(x,K,lambda);
end
function [ soft_thresh ] = softthresholding( b,T )
soft_thresh = sign(b).*max(abs(b) - T,0);
end