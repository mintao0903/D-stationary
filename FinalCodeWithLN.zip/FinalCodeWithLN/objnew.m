function F = objnew(x, A, b, lambda, K)
F = 0.5*norm(A*x-b)^2 + lambda*norm(x,1) -g(x,K,lambda);
end
function v = g(x,K,lambda)
y = sort(abs(x),'descend');
v = lambda*sum(y(1:K));
end