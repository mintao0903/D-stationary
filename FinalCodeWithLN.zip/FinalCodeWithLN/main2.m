clc; close all; 
rng(10)
K = 10;%%for each setting, run K times and get average
J = 10;  obj_record = zeros(K,7);
        time_record = zeros(K,7);
       
 for kk = 1:K
    for j =2:2
        n = 500*j;K = 150*j;
        lambda = 5*j;
        v = randn(K,1);
        [~,index] = sort(abs(v),'descend');
        v = v(index);
        x_real = zeros(n,1);
        for i = 1:K
            x_real(i) = v(i)+sign(v(i));
        end
        x_real(K+1) = v(K)+sign(v(K));
        x_real(K+2) = x_real(K+1);
        d = unifrnd(-sqrt(lambda),sqrt(lambda),n,1);
        d = sort(d,'descend');
        A = diag(d) + 0.01*unifrnd(-1/n,1/n,n,n);
        w1 = lambda*sign(x_real);
        w2 = zeros(n,1);
        w2(1:K) = lambda*sign(x_real(1:K));
        b = A'\(A'*A*x_real+w1-w2);
        
        pm.L = norm(A'*A);
        pm.tau = 0.99;
        pm.c = pm.tau*pm.tau*pm.L;
        pm.eta = 0.1;
        x0 = x_real + 0.05*unifrnd(-1,1,n,1);
        t1 = cputime;
        [x,output] =PEDCA(A, b, K, lambda, pm, x0);%PEDCAe
        t1 = cputime - t1;
        tmp = objnew(x, A, b, lambda, K);
        obj_record(kk,1)  = tmp;
        time_record(kk,1) = t1;
        fprintf('\nExperiment on K = %d, n = %d, lambda = %d', K,n,lambda);
        fprintf('\n PEDCAe:obj  value = %f, t=%4.2f\n',objnew(x,A,b,lambda,K),t1);
         t2 = cputime;
        [x2,output2] = PEDCA(A, b, K, lambda, pm, x0);%PEDCA
        t2 = cputime - t2;
        tmp = objnew(x2, A, b, lambda, K);
        obj_record(kk,2)  = tmp;
        time_record(kk,2) = t2;
        
        fprintf('\n PEDCA:obj  value = %f, t=%4.2f\n',objnew(x2,A,b,lambda,K),t2);
        
        pm.tau = 1; 
        t3=cputime;
        [x3,output3] = PDCAe(A,b,K,lambda,pm,x0);%sPDCAe
        t3=cputime-t3;
         obj_record(kk,3)  = objnew(x3,A,b,lambda,K);
        time_record(kk,3) = t3;
         fprintf('\n PDCAe   obj  value = %f, t=%4.2f\n',objnew(x3,A,b,lambda,K),t3);

      
        fprintf('\n------------------------------------------------------------------------------\n')
    end
   
    
     
 end
     m_obj=mean(obj_record);
     m_time=mean(time_record);
     fprintf('\n------------------------------------------------------------------------------\n')
     disp('   PEDCAe& & PEDCA &sPDCAe   \n');
     disp(m_obj);
     fprintf('\n------------------------------------------------------------------------------\n')
     disp(m_time);