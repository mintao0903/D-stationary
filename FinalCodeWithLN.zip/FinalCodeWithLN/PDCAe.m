function [x,output] = PDCAe(A,b,K,lambda,pm,x_input)
%% converge to a critical point
if isfield(pm,'L')
    L = pm.L;
else
    L = norm(A'*A);
end
if isfield(pm,'tau')
    tau = pm.tau;
else
    tau = 1;
end
xold = x_input; x = xold;theta0 = 1;
theta = 1; N = length(xold);
output.obj = [];
for k = 1:5000
    beta = tau*(theta0-1)/theta;
    z = x+beta*(x-xold);
    [~,ind] = sort(abs(x),'descend');
    I = ind(1:K);
    G = grad(z,I,lambda,N);
    xnew = softthresholding((L*z-A'*(A*z-b)+G)/(L),lambda/(L));
    xold = x; x = xnew; theta0 = theta;
    theta = (1+sqrt(1+4*theta*theta))/2;
    output.obj = [output.obj, obj(x,A,b,lambda,K)];
    if abs(obj(x,A,b,lambda,K)-obj(xold,A,b,lambda,K))<=1e-8 && k>5
        break
    end
    if mod(k,200)==0 || (z-x)'*(x-xold)>0
        theta = 1;
        theta0 = 1;
    end
end
end
function v = g(x,K,lambda)
y = sort(abs(x),'descend');
v = lambda*sum(y(1:K));
end
function G = grad(x,I,lambda,N)
G = zeros(N,1);
for i = 1:length(I)
    if x(I(i))>0
        G(I(i)) = lambda;
    elseif x(I(i))<0
        G(I(i)) = -lambda;
    end
end
end
function F = obj(x,A,b,lambda,K)
F = 0.5*norm(A*x-b)^2+lambda*norm(x,1)-g(x,K,lambda);
end
function [ soft_thresh ] = softthresholding( b,T )
soft_thresh = sign(b).*max(abs(b) - T,0);
end