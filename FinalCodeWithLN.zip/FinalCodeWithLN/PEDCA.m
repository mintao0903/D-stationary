function [x,output] = PEDCA(A,b,K,lambda,pm,x_input)
%%%   based on Algorithm 3 in 'NONMONOTONE ENHANCED PROXIMAL DC ALGORITHMS
%%%   FOR A CLASS OF STRUCTURED NONSMOOTH DC PROGRAMMING'with Beta=0

%%%   x: the output solution
%%%   output.obj: record the value of objective function at each iteration
%%%   output.count: record the number of elements in A(x,eta) at each iteration
if isfield(pm,'maxit')
    maxit = pm.maxit;
else
    maxit = 1e4;
end
if isfield(pm,'L')
    L = pm.L;
else
    L = norm(A'*A);
end
if isfield(pm,'tau')
    tau = pm.tau;
else
    tau = 0.99;
end
if isfield(pm,'c')
    c = pm.c;
else
    c = tau*tau*L;
end
if isfield(pm,'eta')
    eta = pm.eta;
else
    eta = 0.01;
end
% AtA=A'*A;
Atb = A'*b;
At = A';
xold = x_input;
x = xold;
N = length(xold);
output.obj = obj(x,A,b,lambda,K);
obj_min = output.obj(1);
output.count = [];
output.ite_num = 0;
for k = 1:maxit
    z = x;
    v = g(x,K,lambda);%% value of g(x),i.e. lambda*sum of top k largest component of x in magnitude
    [x_sort,ind] = sort(abs(x),'descend');
    F_min = inf;
    %%%get rid of some elements in x that are impossible to appear in A(x,eta)
    sum1 = sum(x_sort(1:K-1));
    for kk = K+1:N
        if lambda*(sum1+x_sort(kk)) < v-eta
            break
        end
    end
    count = 0;
    j = 1;
    temp = [1:K, kk];
    while j <= K
        %%% judge whether the current index combination is in A(x,eta)
        if lambda*sum(x_sort(temp(1:K))) >= v-eta
            %%% get the index before sorting
            I = ind(temp(1:K));
            G = grad(x,I,lambda,N);%%%gradient when the active index is I
            xnew = softthresholding(z-(At*(A*z)-Atb-G)/L,lambda/(L));%%% solve sub problem by softthresholding
            obj_new = obj(xnew,A,b,lambda,K);
            F = obj_new+0.5*c*norm(xnew-x,2)^2;
            if F < F_min
                F_min = F;
                xmin = xnew;
                obj_min  = obj_new;
            end
            count = count+1;
        end
        j = 1;
        while j <= K && temp(j)+1 == temp(j+1)
            temp(j) = j;
            j = j+1;
        end
        temp(j) = temp(j)+1;
    end
    
    xold = x;
    x = xmin;
    output.obj = [output.obj, obj_min];
    output.count = [output.count, count];
    output.ite_num = k;
%     if  abs(f(x,A,b,lambda)-f(xold,A,b,lambda)) <= 1e-8 && k > 5
    if abs(obj_min-obj(xold,A,b,lambda,K))<=1e-8 && k>5
        break
    end
end
end

%%% lambda*sum of top k largest component of x in magnitude
function v = g(x,K,lambda)
y = sort(abs(x),'descend');
v = lambda*sum(y(1:K));
end
%%% gradient when the active index is I
function G = grad(x,I,lambda,N)
G = zeros(N,1);
for i = 1:length(I)
    if x(I(i)) > 0
        G(I(i)) = lambda;
    elseif x(I(i)) < 0
        G(I(i)) =  -lambda;
    end
end
end
function F = obj(x,A,b,lambda,K)
F = 0.5*norm(A*x-b,2)^2+lambda*norm(x,1)-g(x,K,lambda);
end
function f0 = f(x,A,b,lambda)
f0 = 0.5*norm(A*x-b)^2+lambda*norm(x,1);
end
function soft_thresh = softthresholding( b,T )
soft_thresh = sign(b).*max(abs(b) - T, 0);
end