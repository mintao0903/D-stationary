function [x_output,output] = mAPG_ALG1(A,b,K,lambda,pm,x_input)
% %
% % Closed solution: proximal mapping of lambda * (||x||_1 - |||x|||_K)
% %
% % Algorithm 1 monotone APG with fixed stepsize
% % title: Accelerated Proximal Gradient Methods for Nonconvex Programming
% % ref:   https://zhouchenlin.github.io/Publications/2015-NIPS-APG_supp.pdf
if isfield(pm,'alphax')
    alphax = pm.alphax;
else
    alphax = 1/(max(eig(A'*A))+1e-6);
end
if isfield(pm,'alphay')
    alphay = pm.alphay;
else
    alphay = alphax;
end

AA = A'*A; Ab = A'*b;
rx = lambda*alphax; ry = lambda*alphay;

x0 = x_input; x1 = x_input; z1 = x_input;
t1 = 1; t0 = 1;

maxit = 5e3;
output.obj = [];
for k = 1:maxit
    % % 0 means k-1, 1 means k, 2 means k+1
    % update y
    y1 = x1 + (t0/t1)*(z1-x1)+((t0-1)/t1)*(x1-x0);

    % update z, v, t
    gy = y1-alphay*(AA*y1-Ab);
    gx = x1-alphax*(AA*x1-Ab);
    z2 = prox_norm1K(K,ry,gy);
    v2 = prox_norm1K(K,rx,gx);
    t2 = (1+sqrt(1+4*t1*t1))/2;

    % uptdae x
    fgz = objnew(z2,A,b,lambda,K);
    fgv = objnew(v2,A,b,lambda,K);
    if fgz < fgv
        x2 = z2;
    else
        x2 = v2;
    end
    obj1 = objnew(x1,A,b,lambda,K);
    obj2 = objnew(x2,A,b,lambda,K);
    output.obj = [output.obj, obj2];
    if abs(obj2-obj1) < 1e-8 && k >= 5
        break;
    end

    x0 = x1; x1 = x2;
    t0 = t1; t1 = t2;
    z1 = z2; 
end
x_output = x2;
end

%% 
function out = prox_norm1K(K,lambda,x)
% proximal mapping of lambda * (||x||_1 - |||x|||_K)
out = sign(x) .* max(abs(x)-lambda,0);
[~,ind] = sort(abs(x),'descend');
out(ind(1:1:K),1) = x(ind(1:1:K),1); 
end